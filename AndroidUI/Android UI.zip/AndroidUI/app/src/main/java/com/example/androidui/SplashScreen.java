package com.example.androidui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

//This is first screen
public class SplashScreen extends AppCompatActivity {
    private static int splashTimeOut=3000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.screen_splash);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                Intent splashIntent=new Intent(SplashScreen.this,LoginActivity.class);
                startActivity(splashIntent);
                finish();
            }
        },splashTimeOut);
    }
}
